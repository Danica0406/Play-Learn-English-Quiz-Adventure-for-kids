const questions = [
    { question: "What is the opposite of 'big'?", options: ["Tiny", "Large", "Tall"], answer: "Tiny" },
    { question: "A baby cat is called a...", options: ["Puppy", "Kitten", "Cub"], answer: "Kitten" },
    { question: "Which word is an action word (verb)?", options: ["Jump", "Red", "Table"], answer: "Jump" },
    { question: "'The bird ___ singing.' Fill in the blank.", options: ["is", "are", "am"], answer: "is" },
    { question: "Which spelling is correct for the color of a banana?", options: ["Yello", "Yelow", "Yellow"], answer: "Yellow" },
    { question: "How many legs does a dog usually have?", options: ["Two", "Four", "Six"], answer: "Four" },
    { question: "What sound does a cow make?", options: ["Oink", "Moo", "Meow"], answer: "Moo" },
    { question: "Which of these is a fruit?", options: ["Carrot", "Apple", "Potato"], answer: "Apple" },
    { question: "What do bees make?", options: ["Milk", "Honey", "Juice"], answer: "Honey" },
    { question: "Which shape has three sides?", options: ["Circle", "Square", "Triangle"], answer: "Triangle" },
    { question: "What do you wear on your feet?", options: ["Hat", "Shoes", "Gloves"], answer: "Shoes" },
    { question: "Which animal lives in the ocean and has fins?", options: ["Bird", "Fish", "Lion"], answer: "Fish" },
    { question: "What is the day after Sunday?", options: ["Saturday", "Monday", "Tuesday"], answer: "Monday" },
    { question: "We use our ___ to see.", options: ["Ears", "Nose", "Eyes"], answer: "Eyes" },
    { question: "What is the opposite of 'happy'?", options: ["Glad", "Sad", "Angry"], answer: "Sad" },
    { question: "Which word means 'very small'?", options: ["Giant", "Huge", "Tiny"], answer: "Tiny" },
    { question: "Spell the number '5'.", options: ["Fife", "Five", "Fiv"], answer: "Five" },
    { question: "A place where you read books is a...", options: ["Kitchen", "Library", "Park"], answer: "Library" },
    { question: "What color is grass?", options: ["Blue", "Green", "Red"], answer: "Green" },
    { question: "Which animal says 'woof'?", options: ["Cat", "Dog", "Pig"], answer: "Dog" },
    { question: "How many days are in a week?", options: ["Five", "Seven", "Ten"], answer: "Seven" },
    { question: "What do you use to write on paper?", options: ["Fork", "Pencil", "Spoon"], answer: "Pencil" },
    { question: "Which of these flies in the sky?", options: ["Car", "Boat", "Airplane"], answer: "Airplane" },
    { question: "What is the first letter of 'Apple'?", options: ["P", "A", "L"], answer: "A" },
    { question: "What is the opposite of 'cold'?", options: ["Hot", "Warm", "Cool"], answer: "Hot" }
];

const startScreen = document.getElementById('start-screen');
const quizScreen = document.getElementById('quiz-screen');
const endScreen = document.getElementById('end-screen');

const startButton = document.getElementById('start-button');
const playAgainButton = document.getElementById('play-again-button');

const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const feedbackText = document.getElementById('feedback-text');

const progressText = document.getElementById('progress-text');
const scoreText = document.getElementById('score-text');
const finalScoreText = document.getElementById('final-score-text');
const endMessageText = document.getElementById('end-message-text');

let currentQuestionIndex = 0;
let score = 0;

startButton.addEventListener('click', startQuiz);
playAgainButton.addEventListener('click', startQuiz); // Re-use startQuiz for play again

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    shuffleArray(questions); // Shuffle questions for variety each time
    startScreen.style.display = 'none';
    endScreen.style.display = 'none';
    quizScreen.style.display = 'block';
    updateScoreDisplay();
    loadQuestion();
}

// Fisher-Yates shuffle algorithm
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function loadQuestion() {
    feedbackText.textContent = ''; // Clear previous feedback
    optionsContainer.innerHTML = ''; // Clear previous options

    if (currentQuestionIndex < questions.length) {
        const currentQuestion = questions[currentQuestionIndex];
        questionText.textContent = currentQuestion.question;
        progressText.textContent = `Question ${currentQuestionIndex + 1} of ${questions.length}`;

        // Shuffle options for each question
        const shuffledOptions = [...currentQuestion.options];
        shuffleArray(shuffledOptions);

        shuffledOptions.forEach(option => {
            const button = document.createElement('button');
            button.textContent = option;
            button.classList.add('option-button');
            button.addEventListener('click', () => selectAnswer(option, currentQuestion.answer, button));
            optionsContainer.appendChild(button);
        });
    } else {
        showEndScreen();
    }
}

function selectAnswer(selectedOption, correctAnswer, button) {
    // Disable all option buttons after an answer is selected
    const optionButtons = optionsContainer.querySelectorAll('.option-button');
    optionButtons.forEach(btn => btn.disabled = true);

    if (selectedOption === correctAnswer) {
        score++;
        feedbackText.textContent = '🌟 Correct! Great job! 🌟';
        feedbackText.style.color = '#28a745'; // Green
        button.classList.add('correct');
    } else {
        feedbackText.textContent = `Oops! The right answer was: ${correctAnswer}`;
        feedbackText.style.color = '#dc3545'; // Red
        button.classList.add('incorrect');
        // Highlight the correct answer
        optionButtons.forEach(btn => {
            if (btn.textContent === correctAnswer) {
                btn.classList.add('correct');
            }
        });
    }
    updateScoreDisplay();

    // Wait a bit then move to next question or end screen
    setTimeout(() => {
        currentQuestionIndex++;
        loadQuestion();
         // Re-enable buttons for the next question by clearing and re-adding them in loadQuestion
    }, 2000); // 2 seconds delay to see feedback
}

function updateScoreDisplay() {
    scoreText.textContent = `Score: ${score}`;
}

function showEndScreen() {
    quizScreen.style.display = 'none';
    endScreen.style.display = 'block';
    finalScoreText.textContent = `Your final score is: ${score} out of ${questions.length}!`;
    
    let message = "Well done, adventurer!";
    if (score === questions.length) {
        message = "🎉 Perfect score! You're an English Whiz! 🎉";
    } else if (score >= questions.length * 0.75) {
        message = "⭐ Amazing job! You know a lot! ⭐";
    } else if (score >= questions.length * 0.5) {
        message = "👍 Good effort! Keep practicing! 👍";
    } else {
        message = "😊 Nice try! Every adventure helps you learn! 😊";
    }
    endMessageText.textContent = message;
}